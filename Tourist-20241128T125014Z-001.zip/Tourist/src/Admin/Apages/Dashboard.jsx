import React from 'react'
import Aheader from '../Acoman/Aheader'

function Dashboard() {
  return (
    <div>
        <Aheader heading="Admin" />
      <h1>Dashboard</h1>
    </div>
  )
}

export default Dashboard
